package homework_1;

public class task3 {
    public static float task1(float a, float b, float c, float d){
        return a * (b +(c / d));
    }
}
