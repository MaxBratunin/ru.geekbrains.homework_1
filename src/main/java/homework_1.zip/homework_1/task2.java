package homework_1;

public class task2 {
    public static void main(String[] args) {
        byte a = 1;
        short b = 2;
        int c = 100;
        long d = 1234234;
        float e = 123.123f;
        double f = 12.1234d;
        boolean bln = true; // false
        char c1 = 'A';

        int k = c - a;
        System.out.println(k);
    }
}
