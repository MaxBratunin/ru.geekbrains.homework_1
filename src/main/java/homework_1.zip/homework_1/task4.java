package homework_1;

public class task4 {
    public static boolean task2(int a, int b){
        int c = a + b;
        if (c >= 10 && c <= 20) {
            return true;
        }
        return false;
    }
}
