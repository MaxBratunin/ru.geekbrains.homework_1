package homework_1;

public class task5 {
    public static int isPositiveOrNegative(int a){
        if (a >= 0) {
            System.out.println("Число положительное");
        } else {
            System.out.println("Число отрицательное");
        }
    }
}
