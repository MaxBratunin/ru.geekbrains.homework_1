package homework_1;

public class task6 {
    public static boolean task6(int a){
        return a >= 0;
    }
}
